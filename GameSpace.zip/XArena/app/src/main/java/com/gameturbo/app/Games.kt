package com.gameturbo.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream

object Games {

    data class GameApp(val pkg: String, val label: String, val icon: Drawable)

    /** Game populer: dianggap game kalau terpasang. */
    private val KNOWN = setOf(
        "com.mobile.legends",
        "com.roblox.client",
        "com.artofthestate.airwar",
        "com.paradyme.solarsmash",
        "com.JindoBlu.TwoPlayerGamesChallenge",
        "com.tencent.ig",
        "com.pubg.imobile",
        "com.dts.freefireth",
        "com.dts.freefiremax",
        "com.miHoYo.GenshinImpact",
        "com.activision.callofduty.shooter",
        "com.garena.game.codm",
        "com.supercell.clashofclans",
        "com.supercell.brawlstars",
        "com.kiloo.subwaysurf",
        "com.innersloth.spacemafia",
        "com.mojang.minecraftpe"
    )

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("turbo", Context.MODE_PRIVATE)

    /** Semua app yang punya ikon launcher: (package, nama), terurut. */
    fun launchable(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != ctx.packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    @Suppress("DEPRECATION")
    private fun looksLikeGame(ctx: Context, pkg: String): Boolean {
        if (pkg in KNOWN) return true
        return try {
            val info = ctx.packageManager.getApplicationInfo(pkg, 0)
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isGame = (Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME) ||
                ((info.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
            !isSystem && isGame
        } catch (e: Exception) {
            false
        }
    }

    /** Set package game: deteksi otomatis + pilihan manual - yang disembunyikan. */
    fun gamePackages(ctx: Context): Set<String> {
        val p = prefs(ctx)
        val manual = p.getStringSet("games", emptySet()) ?: emptySet()
        val hidden = p.getStringSet("hidden", emptySet()) ?: emptySet()
        val out = LinkedHashSet<String>()
        for ((pkg, _) in launchable(ctx)) {
            if (pkg in hidden) continue
            if (pkg in manual || looksLikeGame(ctx, pkg)) out.add(pkg)
        }
        return out
    }

    fun load(ctx: Context): List<GameApp> {
        val pm = ctx.packageManager
        val pkgs = gamePackages(ctx)
        return launchable(ctx).filter { it.first in pkgs }.mapNotNull { (pkg, label) ->
            try {
                GameApp(pkg, label, pm.getApplicationIcon(pkg))
            } catch (e: Exception) {
                null
            }
        }
    }

    fun addManual(ctx: Context, pkg: String) {
        val p = prefs(ctx)
        val manual = HashSet(p.getStringSet("games", emptySet()) ?: emptySet())
        val hidden = HashSet(p.getStringSet("hidden", emptySet()) ?: emptySet())
        manual.add(pkg); hidden.remove(pkg)
        p.edit().putStringSet("games", manual).putStringSet("hidden", hidden).apply()
    }

    fun hide(ctx: Context, pkg: String) {
        val p = prefs(ctx)
        val manual = HashSet(p.getStringSet("games", emptySet()) ?: emptySet())
        val hidden = HashSet(p.getStringSet("hidden", emptySet()) ?: emptySet())
        manual.remove(pkg); hidden.add(pkg)
        p.edit().putStringSet("games", manual).putStringSet("hidden", hidden).apply()
    }

    /** Ikon jadi PNG base64 (96px) supaya bisa ditampilkan di halaman lobby. */
    fun iconB64(d: Drawable): String {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
        return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }
}
